from django.contrib import admin
from myapp.models import *

# Register your models here.

admin.site.register(Categeory)
admin.site.register(product)
admin.site.register(Cart)
